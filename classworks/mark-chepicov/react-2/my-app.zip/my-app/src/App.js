import React, { Component } from 'react';
import './main.css';
import Header from './Components/header.js';
import Main from './Components/main.js';
import { BrowserRouter as Router} from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <Header/>
          <Main />
        </div>
      </Router>
    );
  }
}

export default App;