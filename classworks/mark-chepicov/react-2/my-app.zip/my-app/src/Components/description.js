import React from 'react';
import '../main.css';

const Description = ({
  item,
}) => (
  <div className="issue__description">
    <div className="issue__title">
      <h2>{item.title}</h2>
    </div>
    <div className="issue__text">
      {item.description}
    </div>
  </div>
)

export default Description;