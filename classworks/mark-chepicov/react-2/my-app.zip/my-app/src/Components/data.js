export default [
  {
    "id": "242209479",
    "title": "Best way to load a folder of static files?",
    "state": "open",
    "description": "Lorem ipsum",
  },
  {
    "id": "242209480",
    "title": "Slow production build ",
    "state": "open",
    "description": "Lorem ipsum",
  },
  {
    "id": "242209481",
    "title": "Support application version via env variable",
    "state": "open",
    "description":"Lorem ipsum",
  },
  {
    "id": "242209482",
    "title": "Tree Shaking?",
    "state": "open",
    "description": "Lorem ipsum",
  },
  {
    "id": "242209483",
    "title": "Code splitting with import promise in object",
    "state": "closed",
    "description": "Lorem ipsum",
  },
];