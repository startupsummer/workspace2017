import React, { Component } from 'react';
import '../main.css';
import IssueItem from './issue-item.js';

class IssueList extends Component {

  static propTypes = {
    tab: React.PropTypes.string.isRequired,
    title: React.PropTypes.string.isRequired,
    issues: React.PropTypes.array.isRequired,
    openFunc: React.PropTypes.func.isRequired,
    closeFunc: React.PropTypes.func.isRequired,
  }

  constructor(props){
    super(props);
  }

  render() {
    const {
      issues,
      tab,
      text = "",
      openFunc,
      closeFunc,
    } = this.props;
    return (
      <div className="issues-listing__body">
        <ul className="issues">
          {
            this.props.issues
            .filter((item) => this.props.tab === item.state)
            .filter((item) => item.title.indexOf(this.props.text) !== -1)
            .map((item) => (
              <IssueItem
                state={item.state}
                title={item.title}
                issueId={item.id}
                openButton={this.props.openFunc}
                closeButton={this.props.closeFunc}
              />))}
        </ul>
      </div>
    )
  }
}
export default IssueList;
